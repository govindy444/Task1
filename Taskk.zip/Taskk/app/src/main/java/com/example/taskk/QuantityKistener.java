package com.example.taskk;

import java.util.ArrayList;

interface QuantityKistener {

 void onQuantityChange(ArrayList<String> arrayList);
}
